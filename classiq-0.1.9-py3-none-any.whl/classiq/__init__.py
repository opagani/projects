"""Classiq SDK."""

from classiq.client import configure
from classiq.authentication.authentication import register_device as authenticate
from classiq.async_utils import enable_jupyter_notebook
