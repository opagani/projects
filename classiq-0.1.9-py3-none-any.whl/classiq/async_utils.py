def enable_jupyter_notebook():
    import nest_asyncio

    nest_asyncio.apply()
